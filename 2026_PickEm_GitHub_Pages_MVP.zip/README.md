# 2026 College Football Pick 'Em HQ — GitHub Pages MVP

## What this is
A static public microsite with no Google login dependency.

## Files
- index.html — site design
- data.js — standings + weekly data. This is the only file you normally update weekly.

## Publish with GitHub Pages
1. Create a new PUBLIC GitHub repository, e.g. `pickem`.
2. Upload `index.html` and `data.js` to the repository root.
3. In the repository, open Settings > Pages.
4. Under Build and deployment, choose:
   - Source: Deploy from a branch
   - Branch: main
   - Folder: /(root)
5. Save.
6. After GitHub finishes publishing, the site will be at:
   `https://YOUR-GITHUB-USERNAME.github.io/pickem/`

## Add the Week 2 form button
Open data.js and replace:
    "formUrl": ""
with:
    "formUrl": "YOUR_GOOGLE_FORM_URL"

Commit/save the change. The button will appear automatically.

## Weekly updates
For the MVP, only replace/update `data.js`.
The HTML does not need to change unless you want design/features updated.
